=== Category Thumbnail List ===
Contributor: Thi Thao Ngo

Lists categories, post titles and links with thumbnails.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload "categoy-thumbnail-list" to the "/wp-content/plugins/" directory

2. Add the following rows to your themes functions.php

add_theme_support( 'post-thumbnails' );

set_post_thumbnail_size( form_option('thumbnail_size_w&&echo=false'), form_option('thumbnail_size_h&&echo=false'), true );

3. Activate the plugin through the "Plugins" menu in WordPress

4. Add the hook in a post. Example: [categorythumbnaillist 3](where 3 is a categoy id)


