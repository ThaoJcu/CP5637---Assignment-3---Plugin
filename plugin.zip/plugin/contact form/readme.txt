=== Contact Form===
Contributor: Thi Thao Ngo

Add a contact form which includes name, email, subject, message to your post.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload "contact form" to the "/wp-content/plugins/" directory

2. Activate the plugin through the "Plugins" menu in WordPress

3. Add the shortcode [contact_form] in a page/post where you want to display the contact form

